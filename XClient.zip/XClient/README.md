# XClient 0.2 (Forge 1.8.9)

1. Create a Forge 1.8.9 project from a template (e.g. nea89o/Forge1.8.9Template or Polyfrost's 1.8.9 template), JDK 8.
2. Copy `src/main/java/com/xlace/client/**` into the project.
3. Run the client with the template's `runClient` task.

Right Shift = mod menu (also "Mod Menu" button on the title screen).
In the menu: click a card to toggle, "Settings >" (or right click) for per-module options + key bind, "Edit HUD" to drag HUD elements.
Config is saved to .minecraft/config/xclient.json.

Modules: FPS, Ping, CPS, Keystrokes, Toggle Sprint, Freelook (hold Left Alt), Zoom (hold C),
CPS Limiter, TNT Timer, Trajectories.
