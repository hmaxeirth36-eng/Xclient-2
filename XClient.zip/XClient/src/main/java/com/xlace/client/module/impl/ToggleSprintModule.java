package com.xlace.client.module.impl;

import com.xlace.client.module.Module;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;

/** Keeps the sprint key held, so you sprint whenever you walk forward. */
public class ToggleSprintModule extends Module {
    private boolean wasOn;

    public ToggleSprintModule() { super("Toggle Sprint", "Always sprint while moving", true, 0); }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END || mc.thePlayer == null) return;
        int code = mc.gameSettings.keyBindSprint.getKeyCode();
        boolean on = enabled && mc.currentScreen == null;
        if (on) {
            KeyBinding.setKeyBindState(code, true);
            wasOn = true;
        } else if (wasOn) {
            KeyBinding.setKeyBindState(code, code > 0 && Keyboard.isKeyDown(code));
            wasOn = false;
        }
    }
}
