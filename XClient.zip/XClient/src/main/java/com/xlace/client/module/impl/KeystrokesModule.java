package com.xlace.client.module.impl;

import com.xlace.client.gui.Theme;
import com.xlace.client.module.BoolSetting;
import com.xlace.client.module.HudModule;
import net.minecraft.client.gui.Gui;
import org.lwjgl.input.Mouse;

public class KeystrokesModule extends HudModule {
    private static final int S = 24, GAP = 2;
    private final BoolSetting showMouse = bool("Mouse buttons", true);
    private final BoolSetting showCps = bool("Show CPS", true);

    public KeystrokesModule() { super("Keystrokes", "Show WASD and mouse buttons", true, 4, 66); }

    @Override public int width() { return S * 3 + GAP * 2; }
    @Override public int height() { return showMouse.value ? S * 2 + GAP * 2 + 20 : S * 2 + GAP; }

    private void key(String label, boolean down, int px, int py, int w, int h) {
        if (background.value) Theme.rrect(px, py, px + w, py + h, down ? 0xB0FFFFFF : 0x90101018);
        mc.fontRendererObj.drawString(label,
                px + (w - mc.fontRendererObj.getStringWidth(label)) / 2,
                py + (h - 8) / 2, down ? 0x000000 : 0xFFFFFF);
    }

    @Override public void render() {
        int step = S + GAP;
        key("W", mc.gameSettings.keyBindForward.isKeyDown(), step, 0, S, S);
        key("A", mc.gameSettings.keyBindLeft.isKeyDown(), 0, step, S, S);
        key("S", mc.gameSettings.keyBindBack.isKeyDown(), step, step, S, S);
        key("D", mc.gameSettings.keyBindRight.isKeyDown(), step * 2, step, S, S);
        if (showMouse.value) {
            int bw = (width() - GAP) / 2;
            key(showCps.value ? "LMB " + CpsModule.left() : "LMB", Mouse.isButtonDown(0), 0, step * 2, bw, 20);
            key(showCps.value ? "RMB " + CpsModule.right() : "RMB", Mouse.isButtonDown(1), bw + GAP, step * 2, bw, 20);
        }
    }
}
