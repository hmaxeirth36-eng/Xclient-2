package com.xlace.client.gui;

import com.xlace.client.XClient;
import com.xlace.client.module.*;
import net.minecraft.client.gui.GuiScreen;
import org.lwjgl.input.Keyboard;

import java.io.IOException;
import java.util.List;

/** Lunar-style mod menu: card grid, click a card to toggle, "Settings" for per-module options. */
public class ModMenu extends GuiScreen {
    private static final int PW = 400, PH = 270, COLS = 3, CW = 117, CH = 44, GAP = 8;
    private static final int SLIDER_W = 140;

    private int px, py;
    private Module selected, listening;
    private NumberSetting dragging;

    @Override
    public void initGui() {
        px = (width - PW) / 2;
        py = (height - PH) / 2;
    }

    private int cardX(int i) { return px + 16 + (i % COLS) * (CW + GAP); }
    private int cardY(int i) { return py + 42 + (i / COLS) * (CH + GAP); }
    private int rowY(int r) { return py + 68 + r * 26; }
    private int sliderX() { return px + PW - 24 - SLIDER_W; }
    private int rowCount(Module m) { return 2 + m.settings.size(); }

    // ---------------------------------------------------------------- drawing

    @Override
    public void drawScreen(int mx, int my, float pt) {
        drawRect(0, 0, width, height, 0x90000000);
        Theme.rrect(px, py, px + PW, py + PH, Theme.BG);
        Theme.rrect(px, py, px + PW, py + 30, Theme.HEADER);
        fontRendererObj.drawStringWithShadow("X", px + 14, py + 11, Theme.ACCENT);
        fontRendererObj.drawStringWithShadow("CLIENT", px + 24, py + 11, Theme.WHITE);
        if (selected == null) drawGrid(mx, my); else drawSettings(mx, my);
    }

    private void headerButton(String text, int mx, int my) {
        boolean hov = Theme.in(mx, my, px + PW - 76, py + 7, 62, 16);
        Theme.rrect(px + PW - 76, py + 7, px + PW - 14, py + 23, hov ? Theme.ACCENT : Theme.CARD);
        drawCenteredString(fontRendererObj, text, px + PW - 45, py + 11, Theme.WHITE);
    }

    private void drawGrid(int mx, int my) {
        headerButton("Edit HUD", mx, my);
        List<Module> all = XClient.modules.all;
        for (int i = 0; i < all.size(); i++) {
            Module m = all.get(i);
            int x = cardX(i), y = cardY(i);
            Theme.rrect(x, y, x + CW, y + CH, Theme.in(mx, my, x, y, CW, CH) ? Theme.CARD_HOVER : Theme.CARD);
            fontRendererObj.drawStringWithShadow(m.name, x + 8, y + 8, Theme.WHITE);
            Theme.toggle(x + CW - 32, y + 7, m.enabled);
            fontRendererObj.drawString(fontRendererObj.trimStringToWidth(m.desc, CW - 16), x + 8, y + 22, Theme.MUTED);
            boolean sh = Theme.in(mx, my, x + CW - 62, y + CH - 15, 56, 14);
            String st = "Settings >";
            fontRendererObj.drawString(st, x + CW - 8 - fontRendererObj.getStringWidth(st), y + CH - 13,
                    sh ? Theme.ACCENT : Theme.MUTED);
        }
    }

    private void drawSettings(int mx, int my) {
        Module m = selected;
        headerButton("< Back", mx, my);
        fontRendererObj.drawStringWithShadow(m.name, px + 20, py + 40, Theme.WHITE);
        fontRendererObj.drawString(m.desc, px + 20, py + 52, Theme.MUTED);
        for (int r = 0; r < rowCount(m); r++) {
            int ry = rowY(r);
            Theme.rrect(px + 16, ry, px + PW - 16, ry + 22, Theme.CARD);
            int right = px + PW - 24;
            if (r == 0) {
                fontRendererObj.drawString("Enabled", px + 24, ry + 7, Theme.WHITE);
                Theme.toggle(right - 24, ry + 5, m.enabled);
            } else if (r == 1) {
                fontRendererObj.drawString(m.hold() ? "Hold key" : "Toggle key", px + 24, ry + 7, Theme.WHITE);
                boolean lis = listening == m;
                Theme.rrect(right - 100, ry + 3, right, ry + 19, lis ? Theme.ACCENT : Theme.CARD_HOVER);
                String t = lis ? "Press a key..." : (m.key == 0 ? "NONE" : Keyboard.getKeyName(m.key));
                drawCenteredString(fontRendererObj, t, right - 50, ry + 7, Theme.WHITE);
            } else {
                Setting s = m.settings.get(r - 2);
                fontRendererObj.drawString(s.name, px + 24, ry + 7, Theme.WHITE);
                if (s instanceof BoolSetting) {
                    Theme.toggle(right - 24, ry + 5, ((BoolSetting) s).value);
                } else if (s instanceof NumberSetting) {
                    NumberSetting n = (NumberSetting) s;
                    int sx = sliderX();
                    Theme.rrect(sx, ry + 9, sx + SLIDER_W, ry + 13, Theme.OFF);
                    int fill = (int) (SLIDER_W * (n.value - n.min) / (n.max - n.min));
                    Theme.rrect(sx, ry + 9, sx + Math.max(2, fill), ry + 13, Theme.ACCENT);
                    net.minecraft.client.gui.Gui.drawRect(sx + fill - 2, ry + 6, sx + fill + 2, ry + 16, Theme.WHITE);
                    String v = n.display();
                    fontRendererObj.drawString(v, sx - 8 - fontRendererObj.getStringWidth(v), ry + 7, Theme.MUTED);
                }
            }
        }
        if (listening != null) {
            fontRendererObj.drawString("Press a key to bind, ESC to clear", px + 20, py + PH - 14, Theme.MUTED);
        }
    }

    // ------------------------------------------------------------------ input

    private void updateSlider(NumberSetting n, int mx) {
        double t = Math.max(0, Math.min(1, (mx - sliderX()) / (double) SLIDER_W));
        n.set(n.min + t * (n.max - n.min));
    }

    @Override
    protected void mouseClicked(int mx, int my, int btn) throws IOException {
        if (listening != null) { listening = null; return; }

        if (selected == null) {
            if (Theme.in(mx, my, px + PW - 76, py + 7, 62, 16)) {
                Config.save();
                mc.displayGuiScreen(new HudEditor());
                return;
            }
            List<Module> all = XClient.modules.all;
            for (int i = 0; i < all.size(); i++) {
                int x = cardX(i), y = cardY(i);
                if (!Theme.in(mx, my, x, y, CW, CH)) continue;
                if (btn == 1 || Theme.in(mx, my, x + CW - 62, y + CH - 15, 56, 14)) selected = all.get(i);
                else if (btn == 0) { all.get(i).toggle(); Config.save(); }
                return;
            }
            return;
        }

        if (Theme.in(mx, my, px + PW - 76, py + 7, 62, 16)) {
            selected = null;
            Config.save();
            return;
        }
        if (btn != 0) return;
        Module m = selected;
        for (int r = 0; r < rowCount(m); r++) {
            int ry = rowY(r);
            if (!Theme.in(mx, my, px + 16, ry, PW - 32, 22)) continue;
            if (r == 0) m.toggle();
            else if (r == 1) listening = m;
            else {
                Setting s = m.settings.get(r - 2);
                if (s instanceof BoolSetting) ((BoolSetting) s).value = !((BoolSetting) s).value;
                else if (s instanceof NumberSetting && mx >= sliderX() - 4) {
                    dragging = (NumberSetting) s;
                    updateSlider(dragging, mx);
                }
            }
            Config.save();
            return;
        }
    }

    @Override
    protected void mouseClickMove(int mx, int my, int btn, long t) {
        if (dragging != null) updateSlider(dragging, mx);
    }

    @Override
    protected void mouseReleased(int mx, int my, int state) {
        if (dragging != null) { dragging = null; Config.save(); }
    }

    @Override
    protected void keyTyped(char c, int code) throws IOException {
        if (listening != null) {
            listening.key = code == Keyboard.KEY_ESCAPE ? 0 : code;
            listening = null;
            Config.save();
            return;
        }
        if (code == Keyboard.KEY_ESCAPE && selected != null) { selected = null; return; }
        if (code == XClient.MENU_KEY.getKeyCode()) { mc.displayGuiScreen(null); return; }
        super.keyTyped(c, code);
    }

    @Override
    public void onGuiClosed() { Config.save(); }

    @Override
    public boolean doesGuiPauseGame() { return false; }
}
