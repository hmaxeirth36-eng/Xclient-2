package com.xlace.client.module;

import com.xlace.client.gui.Theme;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.renderer.GlStateManager;

/** A module drawn on the HUD. render() draws at (0,0); position and scale are applied outside. */
public abstract class HudModule extends Module {
    protected final NumberSetting scaleSetting = num("Scale", 1.0, 0.5, 2.0, 0.1);
    protected final BoolSetting background = bool("Background", true);

    public HudModule(String name, String desc, boolean enabled, int x, int y) {
        super(name, desc, enabled, 0);
        this.x = x;
        this.y = y;
    }

    protected String text() { return ""; }
    public int width() { return mc.fontRendererObj.getStringWidth(text()) + 10; }
    public int height() { return 16; }
    public float getScale() { return (float) scaleSetting.value; }

    public void render() { drawTextBox(text()); }

    public final void renderAt() {
        GlStateManager.pushMatrix();
        GlStateManager.translate((float) x, (float) y, 0f);
        GlStateManager.scale(getScale(), getScale(), 1f);
        render();
        GlStateManager.popMatrix();
    }

    protected void drawTextBox(String t) {
        if (background.value) {
            Theme.rrect(0, 0, width(), height(), 0x90101018);
            Gui.drawRect(0, 1, 2, height() - 1, Theme.ACCENT);
        }
        mc.fontRendererObj.drawStringWithShadow(t, 6, 4, 0xFFFFFF);
    }
}
