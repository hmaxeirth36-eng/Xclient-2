package com.xlace.client.module.impl;

import com.xlace.client.module.HudModule;
import net.minecraft.client.network.NetworkPlayerInfo;

public class PingModule extends HudModule {
    public PingModule() { super("Ping", "Show your ping", true, 4, 24); }

    @Override protected String text() {
        int ping = 0;
        if (mc.thePlayer != null && mc.getNetHandler() != null) {
            NetworkPlayerInfo info = mc.getNetHandler().getPlayerInfo(mc.thePlayer.getUniqueID());
            if (info != null) ping = info.getResponseTime();
        }
        return "Ping: " + ping + " ms";
    }
}
