package com.xlace.client.module.impl;

import com.xlace.client.module.BoolSetting;
import com.xlace.client.module.Module;
import com.xlace.client.module.NumberSetting;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;

public class ZoomModule extends Module {
    private final NumberSetting factor = num("Zoom", 4.0, 1.5, 10.0, 0.5);
    private final BoolSetting lowSens = bool("Lower sensitivity", true);
    private boolean applied;
    private float oldFov, oldSens;

    public ZoomModule() { super("Zoom", "Hold key to zoom in", true, Keyboard.KEY_C); }

    @Override public boolean hold() { return true; }

    @SubscribeEvent
    public void onRender(TickEvent.RenderTickEvent e) {
        if (e.phase == TickEvent.Phase.START) {
            if (enabled && key > 0 && mc.currentScreen == null && Keyboard.isKeyDown(key)) {
                oldFov = mc.gameSettings.fovSetting;
                oldSens = mc.gameSettings.mouseSensitivity;
                applied = true;
                mc.gameSettings.fovSetting = oldFov / (float) factor.value;
                if (lowSens.value) mc.gameSettings.mouseSensitivity = oldSens / (float) Math.sqrt(factor.value);
            }
        } else if (applied) {
            mc.gameSettings.fovSetting = oldFov;
            mc.gameSettings.mouseSensitivity = oldSens;
            applied = false;
        }
    }
}
