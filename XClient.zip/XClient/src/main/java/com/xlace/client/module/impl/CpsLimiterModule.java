package com.xlace.client.module.impl;

import com.xlace.client.module.Module;
import com.xlace.client.module.NumberSetting;
import net.minecraftforge.client.event.MouseEvent;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

import java.util.LinkedList;

/** Caps how many left clicks per second the game accepts from YOU (never adds clicks). */
public class CpsLimiterModule extends Module {
    private final NumberSetting max = num("Max CPS", 12, 1, 20, 1);
    private final LinkedList<Long> clicks = new LinkedList<Long>();

    public CpsLimiterModule() { super("CPS Limiter", "Cap your left-click speed", false, 0); }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public void onMouse(MouseEvent e) {
        if (!enabled || e.button != 0 || !e.buttonstate) return;
        long now = System.currentTimeMillis();
        while (!clicks.isEmpty() && now - clicks.getFirst() > 1000L) clicks.removeFirst();
        if (clicks.size() >= (int) max.value) e.setCanceled(true);
        else clicks.add(now);
    }
}
