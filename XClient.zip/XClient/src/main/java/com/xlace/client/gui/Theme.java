package com.xlace.client.gui;

import net.minecraft.client.gui.Gui;

public class Theme {
    public static final int BG = 0xF0121218, HEADER = 0xFF191A22, CARD = 0xFF1E2029,
            CARD_HOVER = 0xFF272A36, ACCENT = 0xFF5B8CFF, ON = 0xFF3DDC84,
            OFF = 0xFF444A5A, MUTED = 0xFF9AA0B5, WHITE = 0xFFFFFFFF;

    /** Rectangle with cut corners (looks rounded at GUI scale). */
    public static void rrect(int x1, int y1, int x2, int y2, int c) {
        Gui.drawRect(x1 + 1, y1, x2 - 1, y2, c);
        Gui.drawRect(x1, y1 + 1, x2, y2 - 1, c);
    }

    public static void toggle(int x, int y, boolean on) {
        rrect(x, y, x + 24, y + 12, on ? ON : OFF);
        Gui.drawRect(on ? x + 14 : x + 2, y + 2, on ? x + 22 : x + 10, y + 10, WHITE);
    }

    public static boolean in(int mx, int my, int x, int y, int w, int h) {
        return mx >= x && my >= y && mx < x + w && my < y + h;
    }
}
