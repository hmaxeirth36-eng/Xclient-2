package com.xlace.client.module;

import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.xlace.client.XClient;
import net.minecraft.client.Minecraft;

import java.io.*;

/** Saves enabled state, position, key and every setting to .minecraft/config/xclient.json */
public class Config {
    private static File file() {
        return new File(Minecraft.getMinecraft().mcDataDir, "config/xclient.json");
    }

    public static void save() {
        try {
            JsonObject root = new JsonObject();
            for (Module m : XClient.modules.all) {
                JsonObject o = new JsonObject();
                o.addProperty("enabled", m.enabled);
                o.addProperty("x", m.x);
                o.addProperty("y", m.y);
                o.addProperty("key", m.key);
                JsonObject s = new JsonObject();
                for (Setting st : m.settings) {
                    if (st instanceof BoolSetting) s.addProperty(st.name, ((BoolSetting) st).value);
                    else if (st instanceof NumberSetting) s.addProperty(st.name, ((NumberSetting) st).value);
                }
                o.add("settings", s);
                root.add(m.name, o);
            }
            File f = file();
            f.getParentFile().mkdirs();
            Writer w = new OutputStreamWriter(new FileOutputStream(f), "UTF-8");
            new GsonBuilder().setPrettyPrinting().create().toJson(root, w);
            w.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static void load() {
        try {
            File f = file();
            if (!f.exists()) return;
            Reader r = new InputStreamReader(new FileInputStream(f), "UTF-8");
            JsonObject root = new JsonParser().parse(r).getAsJsonObject();
            r.close();
            for (Module m : XClient.modules.all) {
                if (!root.has(m.name)) continue;
                JsonObject o = root.getAsJsonObject(m.name);
                if (o.has("enabled")) m.enabled = o.get("enabled").getAsBoolean();
                if (o.has("x")) m.x = o.get("x").getAsInt();
                if (o.has("y")) m.y = o.get("y").getAsInt();
                if (o.has("key")) m.key = o.get("key").getAsInt();
                if (o.has("settings")) {
                    JsonObject s = o.getAsJsonObject("settings");
                    for (Setting st : m.settings) {
                        if (!s.has(st.name)) continue;
                        if (st instanceof BoolSetting) ((BoolSetting) st).value = s.get(st.name).getAsBoolean();
                        else if (st instanceof NumberSetting) ((NumberSetting) st).set(s.get(st.name).getAsDouble());
                    }
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
