package com.xlace.client.module.impl;

import com.xlace.client.module.BoolSetting;
import com.xlace.client.module.Module;
import com.xlace.client.module.NumberSetting;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityTNTPrimed;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

import java.util.Locale;

/** Shows the remaining fuse time above every lit TNT. */
public class TntTimerModule extends Module {
    private final BoolSetting decimals = bool("Decimals", true);
    private final NumberSetting size = num("Text size", 1.0, 0.5, 3.0, 0.1);

    public TntTimerModule() { super("TNT Timer", "Fuse time above lit TNT", true, 0); }

    @SubscribeEvent
    public void onWorld(RenderWorldLastEvent e) {
        if (!enabled || mc.theWorld == null || mc.getRenderViewEntity() == null) return;
        Entity rv = mc.getRenderViewEntity();
        double cx = rv.lastTickPosX + (rv.posX - rv.lastTickPosX) * e.partialTicks;
        double cy = rv.lastTickPosY + (rv.posY - rv.lastTickPosY) * e.partialTicks;
        double cz = rv.lastTickPosZ + (rv.posZ - rv.lastTickPosZ) * e.partialTicks;
        FontRenderer fr = mc.fontRendererObj;
        RenderManager rm = mc.getRenderManager();

        for (Entity en : mc.theWorld.loadedEntityList) {
            if (!(en instanceof EntityTNTPrimed)) continue;
            EntityTNTPrimed tnt = (EntityTNTPrimed) en;
            float t = Math.max(0f, (tnt.fuse - e.partialTicks) / 20f);
            String s = decimals.value ? String.format(Locale.US, "%.2fs", t) : ((int) Math.ceil(t)) + "s";
            int color = t > 2f ? 0x55FF55 : (t > 1f ? 0xFFFF55 : 0xFF5555);
            double x = tnt.lastTickPosX + (tnt.posX - tnt.lastTickPosX) * e.partialTicks - cx;
            double y = tnt.lastTickPosY + (tnt.posY - tnt.lastTickPosY) * e.partialTicks - cy;
            double z = tnt.lastTickPosZ + (tnt.posZ - tnt.lastTickPosZ) * e.partialTicks - cz;
            float sc = 0.025f * (float) size.value;

            GlStateManager.pushMatrix();
            GlStateManager.translate(x, y + 1.4, z);
            GlStateManager.rotate(-rm.playerViewY, 0f, 1f, 0f);
            GlStateManager.rotate(rm.playerViewX, 1f, 0f, 0f);
            GlStateManager.scale(-sc, -sc, sc);
            GlStateManager.disableLighting();
            GlStateManager.disableDepth();
            GlStateManager.enableBlend();
            GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
            int w = fr.getStringWidth(s) / 2;
            Gui.drawRect(-w - 2, -2, w + 2, 9, 0x80000000);
            fr.drawString(s, -w, 0, color);
            GlStateManager.enableDepth();
            GlStateManager.enableLighting();
            GlStateManager.disableBlend();
            GlStateManager.color(1f, 1f, 1f, 1f);
            GlStateManager.popMatrix();
        }
    }
}
