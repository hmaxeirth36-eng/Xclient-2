package com.xlace.client.module.impl;

import com.xlace.client.module.BoolSetting;
import com.xlace.client.module.HudModule;
import net.minecraftforge.client.event.MouseEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

import java.util.LinkedList;

public class CpsModule extends HudModule {
    private static final LinkedList<Long> LEFT = new LinkedList<Long>();
    private static final LinkedList<Long> RIGHT = new LinkedList<Long>();
    private final BoolSetting showRight = bool("Show right click", true);

    public CpsModule() { super("CPS", "Clicks per second", true, 4, 44); }

    // Counts even when the HUD is hidden so Keystrokes can use it.
    // Clicks cancelled by the CPS Limiter are not counted.
    @SubscribeEvent
    public void onMouse(MouseEvent e) {
        if (!e.buttonstate) return;
        if (e.button == 0) LEFT.add(System.currentTimeMillis());
        else if (e.button == 1) RIGHT.add(System.currentTimeMillis());
    }

    private static int count(LinkedList<Long> list) {
        long now = System.currentTimeMillis();
        while (!list.isEmpty() && now - list.getFirst() > 1000L) list.removeFirst();
        return list.size();
    }

    public static int left() { return count(LEFT); }
    public static int right() { return count(RIGHT); }

    @Override protected String text() {
        return "CPS: " + left() + (showRight.value ? " | " + right() : "");
    }
}
